package com.example.fitflowai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10131A)
private val Panel = Color(0xFF1B202B)
private val Accent = Color(0xFFFF7043)
private val Muted = Color(0xFFABB3C2)
private val exercises = listOf(
    Exercise("Bodyweight squat", "Legs • Beginner", "Quads, glutes", "3 sets × 10 reps", "Keep your chest up, sit your hips back, and move only through a comfortable range."),
    Exercise("Push-up", "Chest • Beginner", "Chest, triceps, shoulders", "3 sets × 8 reps", "Keep your body in a straight line and lower with control. Use a wall or bench variation if needed."),
    Exercise("Dumbbell row", "Back • Beginner", "Back, biceps", "3 sets × 10 reps each side", "Support yourself with one hand, keep your back neutral, and pull the weight toward your hip."),
    Exercise("Glute bridge", "Glutes • Beginner", "Glutes, hamstrings", "3 sets × 12 reps", "Lie on your back with knees bent, lift hips gently, and avoid over-arching your lower back."),
    Exercise("Plank", "Core • Beginner", "Abdominals, shoulders", "3 rounds × 20 sec", "Keep your body aligned and breathe steadily. Stop if you feel pain.")
)
data class Exercise(val name: String, val category: String, val muscles: String, val prescription: String, val tips: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FitFlowApp() }
    }
}

@Composable
fun FitFlowApp() {
    var tab by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<Exercise?>(null) }
    var completed by remember { mutableStateOf(setOf<String>()) }
    var meals by remember { mutableStateOf(listOf<MealEntry>()) }
    var message by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("Hi! I can help explain exercises and suggest a beginner-friendly routine. This demo coach uses sample responses; connect a model API on a secure backend for live AI.") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White, onPrimary = Ink
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("FITFLOW", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("Train smarter.", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("●", color = Accent, fontSize = 22.sp)
                }
                if (selected != null) {
                    ExerciseDetail(selected!!, completed.contains(selected!!.name), {
                        completed = if (completed.contains(selected!!.name)) completed - selected!!.name else completed + selected!!.name
                    }, { selected = null })
                } else {
                    when (tab) {
                        "Home" -> HomeScreen(completed.size, { tab = "Exercises" }, { tab = "Plan" })
                        "Exercises" -> ExerciseScreen(completed, { selected = it })
                        "Plan" -> PlanScreen({ tab = "Exercises" })
                        "Progress" -> ProgressScreen(completed)
                        "AI Coach" -> CoachScreen(message, { message = it }, reply, {
                            reply = if (message.isBlank()) "Try asking: “Can you make me a beginner full-body workout?”"
                            else "Demo suggestion for: \"$message\"\\n\\nStart with a comfortable warm-up, choose movements that match your experience and equipment, and prioritize controlled technique. Stop if you feel pain. Live personalized answers will be enabled when an AI API is connected."
                        })
                    }
                }
                Spacer(Modifier.weight(1f))
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Exercises", "Plan", "Nutrition", "AI Coach").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item, onClick = { selected = null; tab = item },
                            icon = { Text(when(item) { "Home" -> "⌂"; "Exercises" -> "▦"; "Plan" -> "✦"; "Nutrition" -> "◉"; else -> "✧" }, fontSize = 18.sp) },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Accent.copy(alpha = .15f), unselectedTextColor = Muted, unselectedIconColor = Muted)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(done: Int, exercisesClick: () -> Unit, planClick: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(22.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("YOUR DAILY RESET", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Small steps.\nStronger you.", fontSize = 31.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
                    Text("A balanced beginner session, at your pace.", color = Muted)
                    Button(onClick = exercisesClick, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Start workout  →") }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("EXERCISES", "$done / 5", Modifier.weight(1f))
            StatCard("TODAY", if (done == 5) "Complete" else "In progress", Modifier.weight(1f))
        } }
        item { Text("Quick access", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { ActionCard("Exercise library", "Find your next movement", "Browse exercises", exercisesClick) }
        item { ActionCard("AI workout planner", "Build a routine around your goals", "Create a plan", planClick) }
        item { Text("Tip: quality before quantity. Choose a level that feels manageable and take breaks when needed.", color = Muted, fontSize = 13.sp) }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text(title, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}
@Composable
fun ActionCard(title: String, subtitle: String, action: String, click: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable(onClick = click).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Text(action, color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ExerciseScreen(completed: Set<String>, onSelect: (Exercise) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Exercise library", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item { Text("Tap an exercise to view instructions and track it.", color = Muted) }
        items(exercises) { exercise ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { onSelect(exercise) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(Accent.copy(alpha = .16f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text("✦", color = Accent, fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(exercise.name, fontWeight = FontWeight.Bold)
                    Text(exercise.category, color = Muted, fontSize = 12.sp)
                    Text(exercise.prescription, color = Accent, fontSize = 12.sp)
                }
                if (completed.contains(exercise.name)) Text("✓", color = Accent, fontSize = 20.sp)
            }
        }
    }
}

@Composable
fun ExerciseDetail(exercise: Exercise, done: Boolean, toggle: () -> Unit, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("← Back to exercises", color = Accent, modifier = Modifier.clickable(onClick = back))
        Box(Modifier.fillMaxWidth().height(170.dp).background(Panel, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("▶", color = Accent, fontSize = 42.sp)
                Text("Exercise video placeholder", color = Muted, fontSize = 12.sp)
                Text("Add a licensed video URL in the next version", color = Muted, fontSize = 10.sp)
            }
        }
        Text(exercise.name, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text(exercise.category, color = Accent)
        StatCard("TARGET MUSCLES", exercise.muscles, Modifier.fillMaxWidth())
        StatCard("SUGGESTED SESSION", exercise.prescription, Modifier.fillMaxWidth())
        Text("How to do it", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(exercise.tips, color = Muted, lineHeight = 23.sp)
        Spacer(Modifier.weight(1f))
        Button(onClick = toggle, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (done) Panel else Accent)) {
            Text(if (done) "✓ Completed — tap to undo" else "Mark exercise complete")
        }
    }
}

@Composable
fun PlanScreen(openLibrary: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Your starter plan", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item { Text("A sample full-body session. Adjust it to your comfort and available equipment.", color = Muted) }
        items(exercises) { e ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("○", color = Accent, fontSize = 20.sp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(e.name, fontWeight = FontWeight.SemiBold)
                    Text(e.prescription, color = Muted, fontSize = 12.sp)
                }
            }
        }
        item { Button(onClick = openLibrary, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("View exercise instructions") } }
        item { Text("AI plan generation is not connected yet; this is a safe demo template, not medical advice.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
fun ProgressScreen(completed: Set<String>) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Your progress", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Today's completed exercises", color = Muted)
        Text("${completed.size} of ${exercises.size}", color = Accent, fontSize = 38.sp, fontWeight = FontWeight.Bold)
        LinearProgressIndicator(progress = { completed.size / exercises.size.toFloat() }, modifier = Modifier.fillMaxWidth(), color = Accent, trackColor = Panel)
        exercises.forEach { e ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (completed.contains(e.name)) "✓" else "○", color = Accent)
                Spacer(Modifier.width(10.dp))
                Text(e.name, modifier = Modifier.weight(1f))
                Text(if (completed.contains(e.name)) "Done" else "Pending", color = Muted, fontSize = 12.sp)
            }
        }
        Text("This first version keeps progress in memory. Database persistence is the next milestone.", color = Muted, fontSize = 12.sp)
    }
}



data class FoodItem(
    val name: String,
    val kcalPer100g: Int,
    val proteinPer100g: Double,
    val carbsPer100g: Double,
    val fatPer100g: Double
)
data class MealEntry(
    val id: Long,
    val name: String,
    val mealType: String,
    val grams: Int,
    val calories: Int,
    val protein: Double,
    val carbs: Double,
    val fat: Double
)

private val foodCatalog = listOf(
    FoodItem("Cooked rice", 130, 2.7, 28.2, 0.3),
    FoodItem("Chapati / roti", 297, 9.0, 46.0, 7.5),
    FoodItem("Cooked dal", 116, 7.5, 20.0, 0.4),
    FoodItem("Boiled egg", 155, 13.0, 1.1, 11.0),
    FoodItem("Banana", 89, 1.1, 22.8, 0.3),
    FoodItem("Plain yogurt / curd", 61, 3.5, 4.7, 3.3),
    FoodItem("Paneer", 265, 18.3, 1.2, 20.8),
    FoodItem("Cooked chicken breast", 165, 31.0, 0.0, 3.6),
    FoodItem("Oats, dry", 389, 16.9, 66.3, 6.9),
    FoodItem("Almonds", 579, 21.2, 21.6, 49.9),
    FoodItem("Apple", 52, 0.3, 13.8, 0.2),
    FoodItem("Boiled potato", 87, 1.9, 20.1, 0.1)
)

@Composable
fun NutritionScreen(
    meals: List<MealEntry>,
    onAdd: (MealEntry) -> Unit,
    onRemove: (MealEntry) -> Unit
) {
    var selectedFood by remember { mutableStateOf(foodCatalog.first().name) }
    var gramsText by remember { mutableStateOf("100") }
    var mealType by remember { mutableStateOf("Lunch") }
    var search by remember { mutableStateOf("") }
    val food = foodCatalog.firstOrNull { it.name == selectedFood } ?: foodCatalog.first()
    val grams = gramsText.toIntOrNull()?.coerceIn(1, 3000) ?: 100
    val calories = (food.kcalPer100g * grams / 100.0).toInt()
    val protein = food.proteinPer100g * grams / 100.0
    val carbs = food.carbsPer100g * grams / 100.0
    val fat = food.fatPer100g * grams / 100.0
    val filtered = foodCatalog.filter { it.name.contains(search, ignoreCase = true) }
    val totalCalories = meals.sumOf { it.calories }
    val totalProtein = meals.sumOf { it.protein }
    val totalCarbs = meals.sumOf { it.carbs }
    val totalFat = meals.sumOf { it.fat }

    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Text("Nutrition & meals", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item { Text("Estimates for the foods you log today.", color = Muted) }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("TODAY'S ESTIMATED INTAKE", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("$totalCalories kcal", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MacroPill("Protein", totalProtein)
                    MacroPill("Carbs", totalCarbs)
                    MacroPill("Fat", totalFat)
                }
                Text("${meals.size} food entries logged", color = Muted, fontSize = 12.sp)
            }
        }
        item { Text("Add a food", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item {
            OutlinedTextField(
                value = search, onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search foods…") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Muted, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
            )
        }
        items(filtered) { item ->
            Row(
                Modifier.fillMaxWidth()
                    .background(if (selectedFood == item.name) Accent.copy(alpha = .14f) else Panel, RoundedCornerShape(12.dp))
                    .clickable { selectedFood = item.name }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(item.name, fontWeight = FontWeight.SemiBold)
                    Text("${item.kcalPer100g} kcal per 100 g", color = Muted, fontSize = 12.sp)
                }
                if (selectedFood == item.name) Text("✓", color = Accent)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Portion calculator", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Selected: ${food.name}", color = Accent)
                OutlinedTextField(
                    value = gramsText, onValueChange = { gramsText = it.filter(Char::isDigit).take(4) },
                    label = { Text("Serving size in grams") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Muted, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )
                Text("$calories kcal  •  Protein ${"%.1f".format(protein)} g", fontWeight = FontWeight.SemiBold)
                Text("Carbs ${"%.1f".format(carbs)} g  •  Fat ${"%.1f".format(fat)} g", color = Muted, fontSize = 13.sp)
                Text("Meal", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Breakfast", "Lunch", "Dinner", "Snack").forEach { type ->
                        FilterChip(selected = mealType == type, onClick = { mealType = type }, label = { Text(type, fontSize = 11.sp) })
                    }
                }
                Button(
                    onClick = {
                        onAdd(MealEntry(System.nanoTime(), food.name, mealType, grams, calories, protein, carbs, fat))
                        gramsText = "100"
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = gramsText.toIntOrNull() in 1..3000,
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("Add to food diary") }
            }
        }
        item { Text("Today's food diary", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        if (meals.isEmpty()) {
            item { Text("No foods logged yet. Choose a food above to get started.", color = Muted) }
        } else {
            items(meals.reversed(), key = { it.id }) { entry ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(entry.name, fontWeight = FontWeight.SemiBold)
                        Text("${entry.mealType} • ${entry.grams} g • ${entry.calories} kcal", color = Muted, fontSize = 12.sp)
                    }
                    TextButton(onClick = { onRemove(entry) }) { Text("Remove", color = Accent) }
                }
            }
        }
        item { Text("Food values are approximate averages. Recipes, brands, and cooking methods change nutrition. This prototype does not save entries after the app restarts.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
fun MacroPill(label: String, amount: Double) {
    Column(Modifier.background(Ink, RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 8.dp)) {
        Text(label, color = Muted, fontSize = 10.sp)
        Text("${amount.toInt()} g", fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun CoachScreen(message: String, onMessage: (String) -> Unit, reply: String, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("AI Coach", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Ask about movements, beginner routines, or exercise alternatives.", color = Muted)
        Column(Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
            Text("FITFLOW COACH", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(reply, lineHeight = 22.sp)
        }
        OutlinedTextField(value = message, onValueChange = onMessage, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Ask your coach…") }, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Muted, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
        Button(onClick = onSend, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Send message") }
    }
}
